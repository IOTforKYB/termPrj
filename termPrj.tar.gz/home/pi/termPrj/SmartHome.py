from flask import Flask, request, render_template, Response
import RPi.GPIO as GPIO
import time
from camera import Camera
def gen(camera):
    while True:
        frame=camera.get_frame()
        yield (b'--frame\r\n'b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

BUZZER = 14
SERVO_PIN = 18
button_pin = 15

GPIO.setup(button_pin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) 
GPIO.setup(SERVO_PIN, GPIO.OUT)
servo = GPIO.PWM(SERVO_PIN, 50)
GPIO.setup(BUZZER, GPIO.OUT)
p = GPIO.PWM(BUZZER,200)
app = Flask(__name__)
do=262
re=294
mi=330
pa=349
sol=392
la=440
si=493
h_do=523
Frq= [(sol,2), (mi,1), (mi,1), (mi,1), (mi,2), (mi,1), (sol,1), (mi,1),(do,2), (mi,1), (sol,1), (mi,1),(do,1), (mi,2),
(sol,1), (mi,1), (mi,2), (do,1),  (do,1),  (do,1),  (do,2), (mi,1), (mi,1), (mi,2), 
(mi,1), (sol,1), (mi,1),(do,2), (mi,1), (sol,1), (mi,1),(do,1), (mi,2), (sol,1), (mi,1), (mi,2),
(do,1),  (do,1),  (do,1),  (do,2), (sol,1), (sol,1), (mi,2), (do,1), (mi,2), (do,1), (mi,1),(do,1), (mi,2), (sol,2),
(do,1), (do,1), (mi,1), (mi,2), (sol,1), (sol,1), (mi,1),(do,1),(mi,2), (do,1), (mi,1),(do,1), (mi,2), (sol,2)]
speed = 0.3    
def button_callback(channel):
    doMusic()
stopMusic = False
def doMusic():
    global stopMusic
    stopMusic = False
    p.start(10)                            
    for fr in Frq:
        if stopMusic: break                
        p.ChangeFrequency(fr[0])           
        time.sleep(speed*fr[1])               
    p.stop()   
#doMusic()    
servo.start(0)
GPIO.add_event_detect(button_pin, GPIO.FALLING, callback=button_callback)

@app.route("/")
def home():
    return render_template('termPrj.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/index/door', methods = ['POST'])
def doorCtl():
    global stopMusic
    data = request.form['door'] 
    if(data == 'open'):
        stopMusic = True
        servo.ChangeDutyCycle(7.5)
        time.sleep(1)
        return render_template('index.html', data="Door Open!")
    elif(data == 'close'):
        servo.ChangeDutyCycle(2.5)
        time.sleep(1)
        return render_template('index.html', data="Door Close!")


@app.route('/index/video_on')
def video_on():
       return Response(gen(Camera()),mimetype = 'multipart/x-mixed-replace; boundary=frame')
   
if __name__ == "__main__":
    app.run(debug=True)
    app.run(host="0.0.0.0",threaded = True)
    