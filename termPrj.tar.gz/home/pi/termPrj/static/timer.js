const alarmBtn = document.getElementById("show-timer");
const alarmList = document.getElementById("alarm-list");
const alarmForm = document.getElementById("forAlarm");
const alarmInput = document.querySelector("#alarm-form input");

const ALARM_KEY = "alarms";
let alarms = [];

function setAlarm(event){
    event.preventDefault();
    if (alarmBtn.innerText === "➕ Alarm"){
        alarmForm.classList.remove("hidden");
        alarmBtn.innerText = "Hide Alarm";
    }
    else {
        alarmForm.classList.add("hidden");
        alarmBtn.innerText = "➕ Alarm"
    }
}

function saveAlarm(event) {
  event.preventDefault();
  localStorage.setItem(ALARM_KEY, JSON.stringify(alarms));
}

function deleteAlarm(event) {
  event.preventDefault();
  const li = event.target.parentElement;
  li.remove();
  alarms = alarms.filter((alArm) => alArm.id !== parseInt(li.id));
  saveAlarm();
}

function paintAlarm(newAlarm) {
  const li = document.createElement("li");
  li.id = newAlarm.id;
  const span = document.createElement("span");
  span.innerText = newAlarm.text;
  const button = document.createElement("button");
  button.innerText = "❌";
  button.addEventListener("click", deleteAlarm);
  li.appendChild(span);
  li.appendChild(button);
  alarmList.appendChild(li);
}

function handleAlarmSubmit(event) {
  event.preventDefault();
  const newalarm = alarmInput.value;
  alarmInput.value = "";
  const newAlarmObj = {
    text: newalarm + " ",
    id: Date.now(),
  };
  alarms.push(newAlarmObj);
  paintAlarm(newAlarmObj);
  saveAlarm();
}

alarmBtn.addEventListener("click",setAlarm);
alarmForm.addEventListener("submit",handleAlarmSubmit);

const savedAlarm = localStorage.getItem(ALARM_KEY);

if (savedAlarm !== null) {
  const parsedAlarm = JSON.parse(savedAlarm);
  alarms = parsedAlarm;
  parsedAlarm.forEach(paintAlarm);
}
