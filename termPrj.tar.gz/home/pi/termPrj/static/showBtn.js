const btn = document.getElementById("show-todo");
const allTodo = document.getElementById("forTodo");

function showtodoList(event){
    event.preventDefault();
    if (btn.innerText === "Show to do"){
        allTodo.classList.remove("hidden");
        btn.innerText = "Hide to do";
    }
    else {
        allTodo.classList.add("hidden");
        btn.innerText = "Show to do"
    }
}
btn.addEventListener("click",showtodoList);