const registerForm = document.querySelector("#registerForm");
const registerInput = registerForm.querySelector("input")
const registerButton = registerForm.querySelector("button")

const loginForm = document.querySelector("#loginForm");
const loginInput = loginForm.querySelector("input");
const loginButton = loginForm.querySelector("button");

const todoAll = document.getElementById("AllTodo");
const clockAll = document.getElementById("Allclock");
const ButtonAll = document.getElementById("showCtlBox");

const HIDDEN_CLASSNAME = "hidden";
const USERNAME_KEY = "username";

const savedUsername = localStorage.getItem(USERNAME_KEY);
const loginUsername = localStorage.getItem("user")
todoAll.classList.add(HIDDEN_CLASSNAME);
clockAll.classList.add(HIDDEN_CLASSNAME);
ButtonAll.classList.add(HIDDEN_CLASSNAME);

function registerBtnSubmit(event) {
    event.preventDefault();
    registerForm.classList.add(HIDDEN_CLASSNAME);
    const username = registerInput.value;
    localStorage.setItem(USERNAME_KEY, username);
    loginForm.classList.remove(HIDDEN_CLASSNAME);
    loginForm.addEventListener("submit", userLogin);
}

function userLogin(event){
    event.preventDefault();
    if (savedUsername === loginUsername) {
        loginForm.classList.add(HIDDEN_CLASSNAME);
        localStorage.setItem("user", loginInput.value);
        event.preventDefault();
        todoAll.classList.remove(HIDDEN_CLASSNAME);
        clockAll.classList.remove(HIDDEN_CLASSNAME);
        ButtonAll.classList.remove(HIDDEN_CLASSNAME);
    } else if (savedUsername !== loginUsername) {
        alert("Not Registerd User!");
    }
}
if(savedUsername === null) { //show form
    registerForm.classList.remove(HIDDEN_CLASSNAME);
    registerForm.addEventListener("submit", registerBtnSubmit);
    loginForm.classList.add(HIDDEN_CLASSNAME);
    
} else { //show greetings   
    loginForm.classList.remove(HIDDEN_CLASSNAME);  
    loginForm.addEventListener("submit", userLogin);
}
